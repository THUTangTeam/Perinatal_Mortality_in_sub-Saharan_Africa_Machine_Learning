from .base_options import BaseOptions
import os

class TrainOptions(BaseOptions):
    """This class includes training options.

    It also includes shared options defined in BaseOptions.
    """

    def initialize(self, parser):
        parser = BaseOptions.initialize(self, parser)
        parser.add_argument('--test_size', type=float, default=0.2, help='ratio of test data')
        parser.add_argument('--target', type=str, default="Perinatal_Death", help='name of target variable in data')
        parser.add_argument('--model', type=str, default="XGBoost", help='name of model')

        return parser
